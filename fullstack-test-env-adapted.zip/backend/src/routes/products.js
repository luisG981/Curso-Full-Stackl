import { Router } from 'express'; import pkg from 'pg'; const { Pool } = pkg;
const router = Router(); const pool = new Pool({ connectionString: process.env.DATABASE_URL });
router.get('/', async (_, res) => { const { rows } = await pool.query('SELECT id, name, price FROM products ORDER BY id'); res.json(rows); });
router.post('/', async (req, res) => { const { name, price } = req.body || {}; if (!name || typeof price !== 'number') return res.status(400).json({ error: 'Invalid payload' });
  const { rows } = await pool.query('INSERT INTO products(name, price) VALUES($1, $2) RETURNING id, name, price', [name, price]); res.status(201).json(rows[0]); });
export default router;