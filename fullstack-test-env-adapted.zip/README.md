# Ambiente de Pruebas — Curso Full Stack Sr (Adaptado al Temario)
Servicios: frontend (React+Vite), backend (Express/REST/GraphQL/JWT), PostgreSQL/pgAdmin, Mongo/Mongo-Express.
Primer uso:
  cp .env.example .env
  docker compose up -d --build
  # Desarrollo local opcional:
  cd frontend && npm install && npm run dev -- --host
  cd backend && npm install && npm run dev
